<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12">
            <h1 class="m-0"><?php echo $__env->yieldContent('title'); ?></h1>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div><?php /**PATH E:\BNSP\laravel8_perpustakaan\resources\views/admin-lte/main-header.blade.php ENDPATH**/ ?>