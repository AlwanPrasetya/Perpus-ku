 <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="/adminlte/dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div><?php /**PATH E:\BNSP\laravel8_perpustakaan\resources\views/admin-lte/preloader.blade.php ENDPATH**/ ?>