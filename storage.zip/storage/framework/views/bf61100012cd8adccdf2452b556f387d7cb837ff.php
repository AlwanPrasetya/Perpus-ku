<!-- jQuery -->
<script src="/adminlte/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="/adminlte/dist/js/adminlte.js"></script><?php /**PATH E:\BNSP\laravel8_perpustakaan\resources\views/admin-lte/javascript.blade.php ENDPATH**/ ?>