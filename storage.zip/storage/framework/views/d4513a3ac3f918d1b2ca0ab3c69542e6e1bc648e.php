
<?php $__env->startSection('title', 'Buku'); ?>
<?php $__env->startSection('active-buku', 'active'); ?>
<?php $__env->startSection('active-data-master', 'active'); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('petugas.buku', [])->html();
} elseif ($_instance->childHasBeenRendered('qKKOwz1')) {
    $componentId = $_instance->getRenderedChildComponentId('qKKOwz1');
    $componentTag = $_instance->getRenderedChildComponentTagName('qKKOwz1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qKKOwz1');
} else {
    $response = \Livewire\Livewire::mount('petugas.buku', []);
    $html = $response->html();
    $_instance->logRenderedChild('qKKOwz1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:petugas.buku>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-lte/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BNSP\laravel8_perpustakaan\resources\views/petugas/buku/index.blade.php ENDPATH**/ ?>