<footer class="main-footer">
    <div class="row justify-content-center">
      <strong>Copyright &copy; Musyahya 2021</strong>
    </div>
</footer><?php /**PATH E:\BNSP\laravel8_perpustakaan\resources\views/admin-lte/footer.blade.php ENDPATH**/ ?>