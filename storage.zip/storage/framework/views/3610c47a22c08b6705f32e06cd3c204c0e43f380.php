<!-- ChartJS -->
<script src="/adminlte/plugins/chart.js/Chart.min.js"></script><?php /**PATH E:\BNSP\laravel8_perpustakaan\resources\views/admin-lte/script/chart.blade.php ENDPATH**/ ?>